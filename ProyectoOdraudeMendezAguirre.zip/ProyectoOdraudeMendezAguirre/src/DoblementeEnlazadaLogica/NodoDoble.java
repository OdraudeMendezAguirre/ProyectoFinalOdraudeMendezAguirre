/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DoblementeEnlazadaLogica;

/**
 *
 * @author mende
 */
public class NodoDoble {
    AlumnoDoble alumno;
    NodoDoble siguiente;
    NodoDoble anterior;
    
    public NodoDoble(AlumnoDoble alumno){
        this(alumno,null,null);
    }
    
    public NodoDoble(AlumnoDoble alumno, NodoDoble s, NodoDoble a){
        this.alumno=alumno;
        siguiente=s;
        anterior=a;
    }
    
}
