/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DoblementeEnlazadaLogica;

/**
 *
 * @author mende
 */
public class ListaDoble {
    private NodoDoble inicio;
    private NodoDoble fin;
    
    public ListaDoble(){
        inicio=null;
        fin=null;
    }
    
    public Boolean vacia(){
        return inicio==null;
    }
    
    public void agregarFinal(AlumnoDoble alumno){
        if(!vacia()){
            fin=new NodoDoble(alumno,null,fin);
            fin.anterior.siguiente=fin;
        }else{
            inicio=fin=new NodoDoble(alumno);
        }
    }
    
    public void agregarInicio(AlumnoDoble alumno){
        if(!vacia()){
            inicio=new NodoDoble(alumno,inicio,null);
            inicio.siguiente.anterior=inicio;
        }else{
            inicio=fin=new NodoDoble(alumno);
        }
    }
    
    public String MostrarInicioFin(){
        NodoDoble aux=inicio;
        String lista="La lista esta vacia";
        if(!vacia()){
            lista="";
            while(aux!=null){
                lista=lista+"Alumno: "+aux.alumno.getNombre()+" Calificacion: "+aux.alumno.getCalificacion()+"\n";
                aux=aux.siguiente;
            }
        }
        return lista;
    }
    
    public String MostrarFinInicio(){
        NodoDoble aux=fin;
        String lista="La lista esta vacia";
        if(!vacia()){
            lista="";
            while(aux!=null){
                lista=lista+"Alumno: "+aux.alumno.getNombre()+" Calificacion: "+aux.alumno.getCalificacion()+"\n";
                aux=aux.anterior;
            }
        }
        return lista;
    }
    
    public void eliminar(String nombre){
        NodoDoble Actual = inicio;
        NodoDoble atras=null;
        while(Actual!=null){
            if(Actual.alumno.nombre.equals(nombre)){
                if(Actual == inicio){
                    inicio=inicio.siguiente;
                    inicio.anterior=null;
                }else{
                    atras.siguiente=Actual.siguiente;
                    Actual.siguiente.anterior=Actual.anterior;
                }
            }
            atras=Actual;
            Actual=Actual.siguiente;
        }
    }
    
    public String modificar(String nombreN, double cal,String nombreV){
        NodoDoble aux=inicio;
        String mensaje="El alumno no se encuentra o la lista esta vacia;"+"\n"+"No ha sido posible continuar con la operacion";
        
        if(!vacia()){
            while(aux!=null){
                if(aux.alumno.nombre.equals(nombreV)){
                    aux.alumno.nombre=nombreN;
                    aux.alumno.calificacion=cal;
                    mensaje="El alumno: "+nombreV+"\n"+"Ha sido modificado por:"+nombreN;
                }
                aux=aux.siguiente;
            }
        }
        return mensaje;
    }
    
    public int posiciones(){
        NodoDoble aux=inicio;
        int c=0;
        while(aux!=null){
            c=c+1;
            aux=aux.siguiente;
        }
        return c;
    }
    
    
    /*public ListaDoble ordenar(){
        NodoDoble Estructura=inicio;
        NodoDoble Cmax=inicio;
        NodoDoble max=inicio;
        ListaDoble lista = new ListaDoble();
        int p;
        for(p=0;p<posiciones();p++){
            max=inicio;
            Cmax=inicio;
        while(Cmax!=null){
            if(max.alumno.calificacion<=Cmax.alumno.getCalificacion()){
                max=Cmax;
                
            }
            Cmax=Cmax.siguiente;
        }
        NodoDoble agregado=max;
        lista.agregarFinal(agregado.alumno);
        eliminar(max.alumno.nombre);
        
        }
        return lista;
    }*/
    
   //Hacer dos ejemplos de consultas con IN
}
