/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DoblementeEnlazadaLogica;

/**
 *
 * @author mende
 */
public class AlumnoDoble {
    protected String nombre;
    protected double calificacion;
    
    public AlumnoDoble(){
        nombre=null;
        calificacion=0.0;
    }
    public AlumnoDoble(String nombre, double calificacion)
    {
        this.calificacion=calificacion;
        this.nombre=nombre;
    }
    public String getNombre(){
        return nombre;
    }
    public double getCalificacion(){
        return calificacion;
    }
}
