/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CSimplementeEnlazadaLogica;


/**
 *
 * @author mende
 */
public class CLista {
    CNodo fin;
    CNodo inicio;
    public CLista(){
        fin=inicio=null;
    }
    public boolean estavacia(){
        return inicio==null;
    }
    public void insertar(CAlumno alumno){
        if(estavacia()){
        inicio= new CNodo(alumno,inicio);
        fin=inicio;
        fin.siguiente=inicio;
        }
        else
            inicio= new CNodo(alumno,inicio);
    }
    
    public String mostrar(){
        String mensaje="";
        CNodo aux;
        aux=inicio;
        if(aux==null){
            mensaje="La lista esta Vacia";
        }
        while(aux!=fin.siguiente){
            mensaje=mensaje+"Alumno: "+aux.alumno.getNombre()+" calificacion: "+aux.alumno.getCalificacion()+"\n";
            aux=aux.siguiente;
        }
        return mensaje;
    }
    
    public String buscar(String nombre){
        CNodo aux=inicio;
        while(aux!=fin.siguiente){
        if(aux.alumno.getNombre().equals(nombre)){
            return ("Alumno: "+aux.alumno.getNombre()+" calificacion: "+aux.alumno.getCalificacion());
        }
        aux=aux.siguiente;
        }
        return ("El alumno no existe");
    }
    
    public void eliminar(String nombre){
        CNodo aux=inicio;
        CNodo aux2=inicio.siguiente;
        if(aux.alumno.getNombre().equals(nombre)){
            inicio=aux.siguiente;
        }
        while(aux2!=fin.siguiente){
            if(aux2.alumno.getNombre().equals(nombre)){
                aux.siguiente=aux2.siguiente;
            }
            aux=aux.siguiente;
            aux2=aux2.siguiente;
        }
    }
    
    public CLista modificar(String nombreA,String nomN,double cal){
        CNodo aux=inicio;
        while(aux!=fin.siguiente){
        if(aux.alumno.getNombre().equals(nombreA)){
            aux.alumno.nombre=nomN;
            aux.alumno.calificacion=cal;
            return this;
        }
        aux=aux.siguiente;
        }
        return null;
    }
    
    public CLista ordenarCalif(){
        
        CNodo max=inicio;
        //for(max=inicio;max!=null;max=max.siguiente){
        CNodo aux = inicio;
        
        while(aux!=null){
            //for(int c=10;c>=0;c++){
            if(max.alumno.calificacion<aux.alumno.calificacion){
                max=aux;
                eliminar(aux.alumno.getNombre());
                inicio= new CNodo(max.alumno,inicio);
                //aux=aux.siguiente;
            }
            if(max.alumno.calificacion==10){
                max=max.siguiente;
            }
            aux=aux.siguiente;
            }
        //}
        return this;
    }
    
}
