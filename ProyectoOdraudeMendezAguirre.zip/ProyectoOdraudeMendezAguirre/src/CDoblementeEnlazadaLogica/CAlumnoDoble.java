/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CDoblementeEnlazadaLogica;

/**
 *
 * @author mende
 */
public class CAlumnoDoble {
    protected String nombre;
    protected double calificacion;
    
    public CAlumnoDoble(){
        nombre=null;
        calificacion=0.0;
    }
    public CAlumnoDoble(String nombre, double calificacion)
    {
        this.calificacion=calificacion;
        this.nombre=nombre;
    }
    public String getNombre(){
        return nombre;
    }
    public double getCalificacion(){
        return calificacion;
    }
}
