/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CDoblementeEnlazadaLogica;

/**
 *
 * @author mende
 */
public class CNodoDoble {
    CAlumnoDoble alumno;
    CNodoDoble siguiente;
    CNodoDoble anterior;
    
    public CNodoDoble(CAlumnoDoble alumno){
        this(alumno,null,null);
    }
    
    public CNodoDoble(CAlumnoDoble alumno, CNodoDoble s, CNodoDoble a){
        this.alumno=alumno;
        siguiente=s;
        anterior=a;
    }
    
}
