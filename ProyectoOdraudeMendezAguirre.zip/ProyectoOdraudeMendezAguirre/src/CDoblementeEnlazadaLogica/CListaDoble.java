/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CDoblementeEnlazadaLogica;

/**
 *
 * @author mende
 */
public class CListaDoble {
    private CNodoDoble inicio;
    private CNodoDoble fin;
    
    public CListaDoble(){
        inicio=null;
        fin=null;
    }
    
    public Boolean vacia(){
        return inicio==null;
    }
    
    public void agregarFinal(CAlumnoDoble alumno){
        if(!vacia()){
            fin=new CNodoDoble(alumno,null,fin);
            fin.anterior.siguiente=fin;
            fin.siguiente=inicio;
        }else{
            inicio=fin=new CNodoDoble(alumno);
        }
    }
    
    public void agregarInicio(CAlumnoDoble alumno){
        if(!vacia()){
            inicio=new CNodoDoble(alumno,inicio,null);
            inicio.siguiente.anterior=inicio;
            inicio.anterior=fin;
        }else{
            inicio=fin=new CNodoDoble(alumno);
        }
    }
    
    public String MostrarInicioFin(){
        CNodoDoble aux=inicio;
        String lista="La lista esta vacia";
        if(!vacia()){
            lista="";
            while(aux!=fin.siguiente){
                lista=lista+"Alumno: "+aux.alumno.getNombre()+" Calificacion: "+aux.alumno.getCalificacion()+"\n";
                aux=aux.siguiente;
            }
        }
        return lista;
    }
    
    public String MostrarFinInicio(){
        CNodoDoble aux=fin;
        String lista="La lista esta vacia";
        if(!vacia()){
            lista="";
            while(aux!=inicio.anterior){
                lista=lista+"Alumno: "+aux.alumno.getNombre()+" Calificacion: "+aux.alumno.getCalificacion()+"\n";
                aux=aux.anterior;
            }
        }
        return lista;
    }
    
    public void eliminar(String nombre){
        CNodoDoble Actual = inicio;
        CNodoDoble atras=null;
        while(Actual!=fin.siguiente){
            if(Actual.alumno.nombre.equals(nombre)){
                if(Actual == inicio){
                    inicio=inicio.siguiente;
                    inicio.anterior=null;
                }else{
                    atras.siguiente=Actual.siguiente;
                    Actual.siguiente.anterior=Actual.anterior;
                }
            }
            atras=Actual;
            Actual=Actual.siguiente;
        }
    }
    
    public String modificar(String nombreN, double cal,String nombreV){
        CNodoDoble aux=inicio;
        String mensaje="El alumno no se encuentra o la lista esta vacia;"+"\n"+"No ha sido posible continuar con la operacion";
        
        if(!vacia()){
            while(aux!=fin.siguiente){
                if(aux.alumno.nombre.equals(nombreV)){
                    aux.alumno.nombre=nombreN;
                    aux.alumno.calificacion=cal;
                    mensaje="El alumno: "+nombreV+"\n"+"Ha sido modificado por:"+nombreN;
                }
                aux=aux.siguiente;
            }
        }
        return mensaje;
    }
    
    public int posiciones(){
        CNodoDoble aux=inicio;
        int c=0;
        while(aux!=fin.siguiente){
            c=c+1;
            aux=aux.siguiente;
        }
        return c;
    }
    
    
    /*public ListaDoble ordenar(){
        NodoDoble Estructura=inicio;
        NodoDoble Cmax=inicio;
        NodoDoble max=inicio;
        ListaDoble lista = new ListaDoble();
        int p;
        for(p=0;p<posiciones();p++){
            max=inicio;
            Cmax=inicio;
        while(Cmax!=null){
            if(max.alumno.calificacion<=Cmax.alumno.getCalificacion()){
                max=Cmax;
                
            }
            Cmax=Cmax.siguiente;
        }
        NodoDoble agregado=max;
        lista.agregarFinal(agregado.alumno);
        eliminar(max.alumno.nombre);
        
        }
        return lista;
    }*/
    
   //Hacer dos ejemplos de consultas con IN
}
