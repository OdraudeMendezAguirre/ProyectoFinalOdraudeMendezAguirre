/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PilaLogica;

/**
 *
 * @author mende
 */
public class Nodo {
    Alumno alumno;
    Nodo anterior;
    public Nodo(){
        anterior=null;
    }
    public Nodo(Alumno alumno,Nodo ant){
       anterior=ant;
       this.alumno=alumno;
    }
}
