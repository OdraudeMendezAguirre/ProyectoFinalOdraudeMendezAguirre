/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PilaLogica;

/**
 *
 * @author mende
 */
public class Lista {
    Nodo fin;
    Nodo inicio;
    public Lista(){
        fin=inicio=null;
    }
    public boolean estavacia(){
        return inicio==null;
    }
    public void insertar(Alumno alumno){
        if(estavacia()){
        fin= new Nodo(alumno,inicio);
        inicio=fin;
        }
        else
            fin= new Nodo(alumno,fin);
    }
    
    public String mostrar(){
        String mensaje="";
        Nodo aux;
        aux=inicio;
        if(aux==null){
            mensaje="La lista esta Vacia";
        }
        while(aux!=null){
            mensaje=mensaje+"Alumno: "+aux.alumno.getNombre()+" calificacion: "+aux.alumno.getCalificacion()+"\n";
            aux=aux.anterior;
        }
        return mensaje;
    }
    
    public String buscar(String nombre){
        Nodo aux=inicio;
        while(aux!=null){
        if(aux.alumno.getNombre().equals(nombre)){
            return ("Alumno: "+aux.alumno.getNombre()+" calificacion: "+aux.alumno.getCalificacion());
        }
        aux=aux.anterior;
        }
        return ("El alumno no existe");
    }
    
    public void eliminar(String nombre){
        Nodo aux=inicio;
        Nodo aux2=inicio.anterior;
        if(aux.alumno.getNombre().equals(nombre)){
            inicio=aux.anterior;
        }
        while(aux2!=null){
            if(aux2.alumno.getNombre().equals(nombre)){
                aux.anterior=aux2.anterior;
            }
            aux=aux.anterior;
            aux2=aux2.anterior;
        }
    }
    
    public Lista modificar(String nombreA,String nomN,double cal){
        Nodo aux=inicio;
        while(aux!=null){
        if(aux.alumno.getNombre().equals(nombreA)){
            aux.alumno.nombre=nomN;
            aux.alumno.calificacion=cal;
            return this;
        }
        aux=aux.anterior;
        }
        return null;
    }
    
    public Lista ordenarCalif(){
        
        Nodo max=inicio;
        //for(max=inicio;max!=null;max=max.siguiente){
        Nodo aux = inicio;
        
        while(aux!=null){
            //for(int c=10;c>=0;c++){
            if(max.alumno.calificacion<aux.alumno.calificacion){
                max=aux;
                eliminar(aux.alumno.getNombre());
                inicio= new Nodo(max.alumno,inicio);
                //aux=aux.siguiente;
            }
            if(max.alumno.calificacion==10){
                max=max.anterior;
            }
            aux=aux.anterior;
            }
        //}
        return this;
    }
    
}
